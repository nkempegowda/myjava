package com.poc.documentservice.handler;

import com.poc.documentservice.entity.Document;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.test.web.reactive.server.WebTestClient;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.netty.http.client.HttpClient;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import static com.poc.documentservice.router.DocumentRouter.URI;
import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.springframework.http.MediaType.APPLICATION_JSON;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.DEFINED_PORT)
public class DocumentHandlerTest {

    public static final String BASE_URL = "http://localhost:8181";

    WebClient webClient;

    @BeforeEach
    void setUp(){
        webClient = WebClient.builder().baseUrl(BASE_URL)
                .clientConnector(new ReactorClientHttpConnector(HttpClient.create().wiretap(true)))
                .build();
    }

    @Autowired
    private WebTestClient webTestClient;

    @Test
    public void testGetAllDocumentsByUserId() throws InterruptedException{

        CountDownLatch countDownLatch = new CountDownLatch(1);

        Mono<Document> documentMono = webClient.get().uri(URI+"/"+523+"/documents")
                .accept(APPLICATION_JSON)
                .retrieve().bodyToMono(Document.class);
        documentMono.subscribe(
                document -> {
                    System.out.println(document.getName()+":"+document.getDocumentId());
                    assertThat(document).isNotNull();
                    // assertThat(userDto.getName()).isNotNull();
                    countDownLatch.countDown();
                });

        countDownLatch.await(2000, TimeUnit.MILLISECONDS);
        assertThat(countDownLatch.getCount()).isEqualTo(0);

    }

}
