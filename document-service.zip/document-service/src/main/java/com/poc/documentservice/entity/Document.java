package com.poc.documentservice.entity;

import java.sql.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Table("document")
public class Document extends Base{
	
	@Id
	@Column("id")
	private Long documentId;
	private Integer userId;
	private String name;
	private String path;
	private Integer active;
}
