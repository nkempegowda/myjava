package com.poc.documentservice.exception;

public class UploadException extends RuntimeException {

    public UploadException(String msg) {
        super(msg);
    }
}
