package com.poc.documentservice.service;

import com.poc.documentservice.entity.Document;

import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public interface DocumentService {
	
	Flux<Document> getAllDocumentsByUserId(Integer userId);
	
	Mono<Document> getDocumentByUserIdAndDocId(Integer userId,Long documentId);

}
