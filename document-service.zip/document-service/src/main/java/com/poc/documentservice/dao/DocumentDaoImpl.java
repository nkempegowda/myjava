package com.poc.documentservice.dao;

import com.poc.documentservice.repository.DocumentRepository;
import org.springframework.beans.factory.annotation.Autowired;

import com.poc.documentservice.entity.Document;

import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
@Service
public class DocumentDaoImpl implements DocumentDao {
	
	@Autowired
	public DocumentRepository documentRepository;
	
	public Flux<Document> getAllDocumentsByUserId(Integer userId){
		
		Flux<Document> documentList = documentRepository.findAllDocumentsByUserId(userId);
		return documentList;
		
	}
	
	public Mono<Document> getDocumentByUserIdAndDocId(Integer userId,Long documentId){
		Mono<Document> document = documentRepository.findDocumentByUserIdAndDocumentId(userId, documentId);
		return document;
		
	}
	

}
