package com.poc.documentservice.router;

import static com.poc.documentservice.service.DocumentsStorageServiceImpl.LOGGER;
import static org.springframework.web.reactive.function.server.RequestPredicates.*;
import static org.springframework.web.reactive.function.server.RouterFunctions.route;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.MediaType;
import org.springframework.http.codec.multipart.FilePart;
import org.springframework.http.codec.multipart.FormFieldPart;
import org.springframework.http.codec.multipart.Part;
import org.springframework.web.reactive.function.BodyExtractors;
import org.springframework.web.reactive.function.server.RequestPredicates;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.RouterFunctions;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.poc.documentservice.handler.DocumentHandler;
import reactor.core.publisher.Mono;

import java.util.Map;

@Configuration
public class DocumentRouter {

	rivate static final Logger LOGGER = LoggerFactory.getLogger(DocumentRouter.class);

	public static final String URI="/jpmc/api/users";
	@Bean
	public static RouterFunction<ServerResponse> documentRouteNest(DocumentHandler documentHandler){
		return RouterFunctions.nest(path("/jpmc/api/users/{id}/documents"),route(GET(""), documentHandler::getAllDocumentsByUserId)
                        .andRoute(GET("/{document-id}"), documentHandler::getDocumentByUserIdAndDocId)
						.andRoute(POST("/uploadDocument"), documentHandler::uploadDocument));
		
	}

	@Bean
	public RouterFunction<ServerResponse> profileRoute(DocumentHandler documentHandler) {
		return RouterFunctions.route(RequestPredicates.method(documentHandler.uploadDocument()).and(RequestPredicates.POST("/uploadDocument").and(RequestPredicates.contentType(MediaType.MULTIPART_FORM_DATA))),
				request -> request.body(BodyExtractors.toMultipartData()).flatMap(parts -> {
							Map<String, Part> partMap = parts.toSingleValueMap();

							partMap.forEach((partName, value) -> {
								LOGGER.info("Name: {}, value: {}", partName, value);
							});

							// Handle file
							FilePart image = (FilePart) partMap.get("image");
							LOGGER.info("File name: {}", image.filename());

							// Handle profile
							FormFieldPart profile = (FormFieldPart) partMap.get("profile");

							return Mono.empty();
						})
						.then(ServerResponse.ok().bodyValue("Profile updated")));
	}
}

}
