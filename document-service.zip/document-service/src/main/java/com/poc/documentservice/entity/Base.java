package com.poc.documentservice.entity;

import java.sql.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Base {
	
	private Integer created_by;
	private Date created_on;
	private Integer updated_by;
	private Date updated_on;

}
