package com.poc.documentservice.handler;


import com.poc.documentservice.response.SuccessResponse;
import com.poc.documentservice.service.DocumentsStorageService;
import com.poc.documentservice.utils.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.codec.multipart.FilePart;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.BodyInserter;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.poc.documentservice.entity.Document;
import com.poc.documentservice.service.DocumentService;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import static org.springframework.web.reactive.function.BodyInserters.fromValue;
import static org.springframework.web.reactive.function.server.ServerResponse.ok;
import static org.springframework.web.reactive.function.server.ServerResponse.seeOther;

@Component
public class DocumentHandler {
	
	@Autowired
	public DocumentService documentService;

    @Autowired
    public DocumentsStorageService documentsStorageService;
	
	public Mono<ServerResponse> getAllDocumentsByUserId(ServerRequest request) {
        Integer userId = Integer.parseInt(request.pathVariable("id"));
        Flux<Document> userDocumentList = documentService.getAllDocumentsByUserId(userId);
        return ok().contentType(MediaType.APPLICATION_JSON).body(userDocumentList, Document.class);
    }

    public Mono<ServerResponse> getDocumentByUserIdAndDocId(ServerRequest request) {
        Integer userId = Integer.parseInt(request.pathVariable("id"));
        Long documentId = (long) Integer.parseInt(request.pathVariable("document-id"));
        
        Mono<Document> userDocument = documentService.getDocumentByUserIdAndDocId(userId, documentId);
		
		return userDocument.flatMap(document ->ok().contentType(MediaType.APPLICATION_JSON)
		  .body(fromValue(document))).switchIfEmpty(ServerResponse.notFound().build());
    }

    public  Mono<SuccessResponse> uploadDocument(Mono<FilePart> filePart){
        return filePart
                .map(file -> {
                    FileUtils.filePartValidator(file);
                    return file;
                })
                .flatMap(documentsStorageService::uploadObject)
                //.map(fileResponse -> new SuccessResponse(fileResponse, "Upload successfully"));
                .map(fileResponse -> ServerResponse.ok().body(new SuccessResponse(fileResponse, "Upload successfully")));

    }
    public Mono<ServerResponse> uploadDoc(ServerRequest request){
        Mono<FilePart> filePart = null;

        Mono<SuccessResponse> fileResponse = uploadDocument(filePart);

        return
    }

}
