package com.poc.documentservice.response;

import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.web.reactive.function.BodyInserter;
import reactor.core.publisher.Mono;

public record SuccessResponse(Object data, String message) {
}
