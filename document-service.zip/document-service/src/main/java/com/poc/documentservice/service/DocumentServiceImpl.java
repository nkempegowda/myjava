package com.poc.documentservice.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.poc.documentservice.dao.DocumentDao;
import com.poc.documentservice.entity.Document;

import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
@Service
public class DocumentServiceImpl implements DocumentService{
	
	@Autowired
	public DocumentDao documentDao;

	@Override
	public Flux<Document> getAllDocumentsByUserId(Integer userId) {
		
		return documentDao.getAllDocumentsByUserId(userId);
	}

	@Override
	public Mono<Document> getDocumentByUserIdAndDocId(Integer userId,Long documentId) {
		
		return documentDao.getDocumentByUserIdAndDocId(userId, documentId);
	}

	
}
