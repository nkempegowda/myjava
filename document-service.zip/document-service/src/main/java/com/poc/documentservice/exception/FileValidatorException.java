package com.poc.documentservice.exception;

public class FileValidatorException extends RuntimeException {

    public FileValidatorException(String msg) {
        super(msg);
    }
}
