package com.poc.documentservice.repository;

import org.springframework.data.repository.reactive.ReactiveCrudRepository;

import com.poc.documentservice.entity.Document;

import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
@Repository
public interface DocumentRepository extends ReactiveCrudRepository<Document,Long> {

	Flux<Document> findAllDocumentsByUserId(Integer userId);
	
	Mono<Document> findDocumentByUserIdAndDocumentId(Integer userId,Long documentId);
}
