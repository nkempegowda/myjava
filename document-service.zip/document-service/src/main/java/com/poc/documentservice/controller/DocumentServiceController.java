package com.poc.documentservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.codec.multipart.FilePart;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;


import com.poc.documentservice.response.SuccessResponse;
import com.poc.documentservice.service.DocumentsStorageService;
import com.poc.documentservice.utils.FileUtils;

import lombok.RequiredArgsConstructor;
import reactor.core.publisher.Mono;

@RestController
@RequiredArgsConstructor
@RequestMapping("/jpmc/api/users/{id}/document")
@Validated
public class DocumentServiceController {
	
	@Autowired
	public DocumentsStorageService documentsStorageService;

	@PostMapping("/uploadDocumnet")
    public Mono<SuccessResponse> saveDocument(@RequestPart("file-data") Mono<FilePart> filePart) {
        return filePart
                .map(file -> {
                    FileUtils.filePartValidator(file);
                    return file;
                })
                .flatMap(documentsStorageService::uploadObject)
                .map(fileResponse -> new SuccessResponse(fileResponse, "Upload successfully"));
    }

    @GetMapping(path="/{documentId}")
    public Mono<SuccessResponse> getDocument(@PathVariable("fileKey") String fileKey) {

        return documentsStorageService.getByteObject(fileKey)
                .map(objectKey -> new SuccessResponse(objectKey, "Object byte response"));
    }
}
