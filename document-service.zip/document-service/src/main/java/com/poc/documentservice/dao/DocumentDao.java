package com.poc.documentservice.dao;

import com.poc.documentservice.entity.Document;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface DocumentDao {
	
	Flux<Document> getAllDocumentsByUserId(Integer userId);
	
	Mono<Document> getDocumentByUserIdAndDocId(Integer userId,Long documentId);

}
