CREATE TABLE IF NOT EXISTS DOCUMENT (
id INT AUTO_INCREMENT PRIMARY KEY ,
  user_id INTEGER,
  created_on DATE,
  created_by varchar(120),
  updated_by varchar(120),
  updated_on DATE,
  name varchar(100),
  path varchar(150),
  active INTEGER
);

INSERT INTO DOCUMENT (user_id,created_by,created_on,updated_by,updated_on,name,path,active)
values (543,'543',CURRENT_DATE,'543',CURRENT_DATE,'PAN1','/documents/pan',1);

INSERT INTO DOCUMENT (user_id,created_by,created_on,updated_by,updated_on,name,path,active)
values (523,'523',CURRENT_DATE,'523',CURRENT_DATE,'PAN2','/documents/pan',1);

